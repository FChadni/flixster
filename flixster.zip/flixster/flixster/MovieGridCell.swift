//
//  MovieGridCell.swift
//  flixster
//
//  Created by Farjana Chadni on 2/27/21.
//

import UIKit

class MovieGridCell: UICollectionViewCell {
    
    @IBOutlet weak var posterView: UIImageView!
}
